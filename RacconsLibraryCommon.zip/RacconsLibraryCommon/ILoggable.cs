﻿namespace RacconsLibraryCommon
{
    public interface ILoggable
    {
        string Log();
    }
}
