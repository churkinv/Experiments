﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RacconsLibraryCommon
{
//    public static class DataStructures
//    {



////Array list
////Linked list
////Hash Set/Hash Map
////Tree Set/Tree Map(Red-Black tree)



//    }

    class Node
    {

    }

    class BT
    {
    }
}
